﻿using Artic.Demo.Application.TodoItems.Commands.CreateTodoItem;
using Artic.Demo.Application.TodoItems.Commands.DeleteTodoItem;
using Artic.Demo.Application.TodoItems.Commands.UpdateTodoItem;
using Artic.Demo.Application.TodoItems.Queries.GetTodoItemById;
using Artic.Demo.Application.TodoItems.Queries.GetTodoItems;
using Artic.Demo.Application.TodoItems.Dtos;
using Artic.Demo.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace Artic.Demo.Api.Controllers
{
    public class TodoItemController : ApiControllerBase
    {
        [HttpPost]
        public async Task<ActionResult<Guid>> Create(CreateTodoItemCommand command)
        {
            return await Mediator.Send(command);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await Mediator.Send(new DeleteTodoItemCommand { Id = id });

            return NoContent();
        }

        [HttpGet]
        public async Task<ActionResult<List<TodoItemBriefDto>>> Get([FromQuery] GetTodoItemsQuery query)
        {
            return await Mediator.Send(query);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TodoItem>> Get(Guid id)
        {
            return await Mediator.Send(new GetTodoItemByIdQuery { Id = id });
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(Guid id, UpdateTodoItemCommand command)
        {
            if (id != command.Id)
            {
                return BadRequest();
            }

            await Mediator.Send(command);

            return NoContent();
        }
    }
}
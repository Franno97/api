﻿using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.TodoItems.Interfaces;
using Artic.Demo.Infrastructure.Persistence;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Infrastructure.Common
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _context;

        public UnitOfWork(ApplicationDbContext context, ITodoItemsRepository todoItemsRepository)
        {
            _context = context;
            TodoItemsRepository = todoItemsRepository;
        }

        public ITodoItemsRepository TodoItemsRepository { get; }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return await _context.SaveChangesAsync(cancellationToken);
        }
    }
}
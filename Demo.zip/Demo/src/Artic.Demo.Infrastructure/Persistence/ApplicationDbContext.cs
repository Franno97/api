﻿using Artic.Demo.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Artic.Demo.Infrastructure.Persistence
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<TodoItem> TodoItems { get; set; }
    }
}
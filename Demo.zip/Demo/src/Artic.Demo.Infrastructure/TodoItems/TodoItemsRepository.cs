﻿using Artic.Demo.Application.TodoItems.Interfaces;
using Artic.Demo.Domain.Entities;
using Artic.Demo.Infrastructure.Common;
using Artic.Demo.Infrastructure.Persistence;

namespace Artic.Demo.Infrastructure.TodoItems
{
    public class TodoItemsRepository : Repository<TodoItem>, ITodoItemsRepository
    {
        public TodoItemsRepository(ApplicationDbContext context)
            : base(context)
        {
        }
    }
}
﻿using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.TodoItems.Interfaces;
using Artic.Demo.Infrastructure.Common;
using Artic.Demo.Infrastructure.Persistence;
using Artic.Demo.Infrastructure.TodoItems;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Artic.Demo.Infrastructure
{
    public static class DependencyInjection
    {
        public static void AddInfrastructureLayer(this IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                    options.UseInMemoryDatabase("ArticDemoDb"));

            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddTransient<IUnitOfWork, UnitOfWork>();

            services.AddTransient<ITodoItemsRepository, TodoItemsRepository>();
        }
    }
}
﻿using Artic.Demo.Domain.Enums;
using System;

namespace Artic.Demo.Domain.Entities
{
    public class TodoItem
    {
        public bool Done { get; set; }

        public Guid Id { get; set; }

        public string Note { get; set; }

        public PriorityLevel Priority { get; set; }

        public DateTime? Reminder { get; set; }

        public string Title { get; set; }
    }
}
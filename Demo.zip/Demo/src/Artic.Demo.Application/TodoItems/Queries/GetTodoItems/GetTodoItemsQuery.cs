﻿using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.Common.RequestHandlers;
using Artic.Demo.Application.TodoItems.Dtos;
using AutoMapper;
using MediatR;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.TodoItems.Queries.GetTodoItems
{
    public class GetTodoItemsQuery : IRequest<List<TodoItemBriefDto>>
    {
    }

    public class GetTodoItemsQueryHandler : BaseRequestHandler, IRequestHandler<GetTodoItemsQuery, List<TodoItemBriefDto>>
    {
        public GetTodoItemsQueryHandler(IMapper mapper, IUnitOfWork unitOfWork)
            : base(mapper, unitOfWork)
        {
        }

        public async Task<List<TodoItemBriefDto>> Handle(GetTodoItemsQuery request, CancellationToken cancellationToken)
        {
            var todoItems = await _unitOfWork.TodoItemsRepository.GetAllAsync(cancellationToken);

            var todoItemsBrief = _mapper.Map<List<TodoItemBriefDto>>(todoItems);

            return todoItemsBrief;
        }
    }
}
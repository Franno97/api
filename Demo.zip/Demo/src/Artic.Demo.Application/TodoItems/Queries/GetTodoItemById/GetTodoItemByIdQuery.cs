﻿using Artic.Demo.Application.Common.Exceptions;
using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.Common.RequestHandlers;
using Artic.Demo.Domain.Entities;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.TodoItems.Queries.GetTodoItemById
{
    public class GetTodoItemByIdQuery : IRequest<TodoItem>
    {
        public Guid Id { get; set; }
    }

    public class GetTodoItemByIdQueryHandler : BaseRequestHandler, IRequestHandler<GetTodoItemByIdQuery, TodoItem>
    {
        public GetTodoItemByIdQueryHandler(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
           
        }

        public async Task<TodoItem> Handle(GetTodoItemByIdQuery request, CancellationToken cancellationToken)
        {
            var todoItem = await _unitOfWork.TodoItemsRepository.GetByIdAsync(request.Id, cancellationToken);

            if (todoItem == null)
            {
                throw new NotFoundException(nameof(TodoItem), request.Id);
            }

            return todoItem;
        }
    }
}
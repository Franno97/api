﻿using FluentValidation;

namespace Artic.Demo.Application.TodoItems.Queries.GetTodoItemById
{
    public class GetTodoItemByIdQueryValidator : AbstractValidator<GetTodoItemByIdQuery>
    {
        public GetTodoItemByIdQueryValidator()
        {
            RuleFor(v => v.Id)
                .NotEmpty().WithMessage("Is required.")
                .NotNull().WithMessage("Must not be null.");
        }
    }
}
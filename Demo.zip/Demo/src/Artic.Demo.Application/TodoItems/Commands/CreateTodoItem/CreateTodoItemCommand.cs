﻿using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.Common.RequestHandlers;
using Artic.Demo.Domain.Entities;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.TodoItems.Commands.CreateTodoItem
{
    public class CreateTodoItemCommand : IRequest<Guid>
    {
        public string Title { get; set; }
    }

    public class CreateTodoItemCommandHandler : BaseRequestHandler, IRequestHandler<CreateTodoItemCommand, Guid>
    {
        public CreateTodoItemCommandHandler(IUnitOfWork unitOfWork)
            : base(unitOfWork)

        
        {
            
        }

        public async Task<Guid> Handle(CreateTodoItemCommand request, CancellationToken cancellationToken)
        {
            var todoItem = new TodoItem
            {
                Title = request.Title,
                Done = false
            };

            await _unitOfWork.TodoItemsRepository.AddAsync(todoItem, cancellationToken);

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            return todoItem.Id;
        }
    }
}
﻿using FluentValidation;

namespace Artic.Demo.Application.TodoItems.Commands.CreateTodoItem
{
    public class CreateTodoItemCommandValidator : AbstractValidator<CreateTodoItemCommand>
    {
        public CreateTodoItemCommandValidator()
        {
            RuleFor(v => v.Title)
                .NotEmpty().WithMessage("Is required.")
                .NotNull().WithMessage("Must not be null.")
                .MaximumLength(255).WithMessage("Must not exceed 255 characters.");
        }
    }
}
﻿using Artic.Demo.Application.Common.Exceptions;
using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.Common.RequestHandlers;
using Artic.Demo.Domain.Entities;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.TodoItems.Commands.DeleteTodoItem
{
    public class DeleteTodoItemCommand : IRequest
    {
        public Guid Id { get; set; }
    }

    public class DeleteTodoItemCommandHandler : BaseRequestHandler, IRequestHandler<DeleteTodoItemCommand>
    {
        public DeleteTodoItemCommandHandler(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
            
        }

        public async Task<Unit> Handle(DeleteTodoItemCommand request, CancellationToken cancellationToken)
        {
            var todoItem = await _unitOfWork.TodoItemsRepository.GetByIdAsync(request.Id, cancellationToken);

            if (todoItem == null)
            {
                throw new NotFoundException(nameof(TodoItem), request.Id);
            }

            _unitOfWork.TodoItemsRepository.Remove(todoItem);

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }
    }
}
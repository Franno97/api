﻿using FluentValidation;

namespace Artic.Demo.Application.TodoItems.Commands.UpdateTodoItem
{
    public class UpdateTodoItemCommandValidator : AbstractValidator<UpdateTodoItemCommand>
    {
        public UpdateTodoItemCommandValidator()
        {
            RuleFor(v => v.Done)
                .NotNull().WithMessage("Must not be null.");

            RuleFor(v => v.Id)
                .NotEmpty().WithMessage("Is required.")
                .NotNull().WithMessage("Must not be null.");

            RuleFor(v => v.Title)
                .NotEmpty().WithMessage("Is required.")
                .NotNull().WithMessage("Must not be null.")
                .MaximumLength(255).WithMessage("Must not exceed 255 characters.");
        }
    }
}
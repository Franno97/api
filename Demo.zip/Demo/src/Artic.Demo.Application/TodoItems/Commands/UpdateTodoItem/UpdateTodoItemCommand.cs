﻿using Artic.Demo.Application.Common.Exceptions;
using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Application.Common.RequestHandlers;
using Artic.Demo.Domain.Entities;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.TodoItems.Commands.UpdateTodoItem
{
    public class UpdateTodoItemCommand : IRequest
    {
        public bool Done { get; set; }

        public Guid Id { get; set; }

        public string Title { get; set; }
    }

    public class UpdateTodoItemCommandHandler : BaseRequestHandler, IRequestHandler<UpdateTodoItemCommand>
    {
        public UpdateTodoItemCommandHandler(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
            
        }

        public async Task<Unit> Handle(UpdateTodoItemCommand request, CancellationToken cancellationToken)
        {
            var todoItem = await _unitOfWork.TodoItemsRepository.GetByIdAsync(request.Id, cancellationToken);

            if (todoItem == null)
            {
                throw new NotFoundException(nameof(TodoItem), request.Id);
            }

            todoItem.Title = request.Title;
            todoItem.Done = request.Done;

            _unitOfWork.TodoItemsRepository.Update(todoItem);

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }
    }
}
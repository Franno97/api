﻿using Artic.Demo.Application.Common.Mappings;
using Artic.Demo.Domain.Entities;
using System;

namespace Artic.Demo.Application.TodoItems.Dtos
{
    public class TodoItemBriefDto : IMapFrom<TodoItem>
    {
        public bool Done { get; set; }

        public Guid Id { get; set; }

        public string Title { get; set; }
    }
}
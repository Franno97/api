﻿using Artic.Demo.Application.Common.Interfaces;
using Artic.Demo.Domain.Entities;

namespace Artic.Demo.Application.TodoItems.Interfaces
{
    public interface ITodoItemsRepository : IRepository<TodoItem>
    {
    }
}
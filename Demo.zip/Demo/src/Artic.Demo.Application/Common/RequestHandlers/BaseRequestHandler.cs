﻿using Artic.Demo.Application.Common.Interfaces;
using AutoMapper;

namespace Artic.Demo.Application.Common.RequestHandlers
{
    public abstract class BaseRequestHandler
    {
        protected BaseRequestHandler()
        {
        }

        protected BaseRequestHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        protected BaseRequestHandler(IMapper mapper, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        protected readonly IMapper _mapper;
        protected readonly IUnitOfWork _unitOfWork;
    }
}
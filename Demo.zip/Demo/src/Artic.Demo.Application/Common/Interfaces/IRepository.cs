﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.Common.Interfaces
{
    public interface IRepository<T>
        where T : class
    {
        Task AddAsync(T entity, CancellationToken cancellationToken);

        Task AddRangeAsync(List<T> entities, CancellationToken cancellationToken);

        Task<List<T>> GetAllAsync(CancellationToken cancellationToken);

        Task<T> GetByIdAsync(Guid id, CancellationToken cancellationToken);

        void Purge();

        void Remove(T entity);

        void RemoveRange(List<T> entities);

       
        void Update(T entity);
    }
}
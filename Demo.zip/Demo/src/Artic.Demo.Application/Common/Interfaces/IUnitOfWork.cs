﻿using Artic.Demo.Application.TodoItems.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace Artic.Demo.Application.Common.Interfaces
{
    public interface IUnitOfWork
    {
        ITodoItemsRepository TodoItemsRepository { get; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}